<?php

namespace Khenop\Exception;

class AmountException extends \Exception
{
}