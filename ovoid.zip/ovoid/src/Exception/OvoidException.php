<?php
namespace Khenop\Exception;

class OvoidException extends \Exception
{
}