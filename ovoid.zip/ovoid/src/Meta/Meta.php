<?php

namespace Khenop\Meta;

/**
 * Meta
 *
 * berisi config
 */
class Meta
{
    const APP_ID = 'C7UMRSMFRZ46D9GW9IK7';
    const APP_VERSION = '2.11.1';
    const OS_NAME = 'Android';
    const OS_VERSION = '8.1.0';
    const MAC_ADDRESS = '02:00:00:44:55:66';
    const DEVICE_ID = '5d1fa7f9-fd99-3bae-95d5-67fedb901502';
}
