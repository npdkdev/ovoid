<?php
namespace Khenop\Response;

class CustomerUnlockResponse
{
    public function __construct($data)
    {
        
    }
}