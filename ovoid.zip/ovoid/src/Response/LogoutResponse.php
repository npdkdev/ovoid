<?php

namespace Khenop\Response;

class LogoutResponse
{
    public function __construct($data)
    {
    }
}
