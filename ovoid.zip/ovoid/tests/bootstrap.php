
21 lines (18 sloc) 709 Bytes
<?php

require __DIR__ . '/../vendor/autoload.php';
error_reporting(-1);